package br.com.aula.aulaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
