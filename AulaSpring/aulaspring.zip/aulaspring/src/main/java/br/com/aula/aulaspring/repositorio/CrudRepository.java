package br.com.aula.aulaspring.repositorio;

public interface CrudRepository<T1, T2> {

}
