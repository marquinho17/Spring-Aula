package br.com.aula.aulaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaspringApplication.class, args);
	}

}
